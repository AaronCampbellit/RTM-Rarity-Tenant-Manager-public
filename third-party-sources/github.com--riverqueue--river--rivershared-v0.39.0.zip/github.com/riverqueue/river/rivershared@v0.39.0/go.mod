module github.com/riverqueue/river/rivershared

go 1.25.0

toolchain go1.25.7

require (
	github.com/jackc/pgx/v5 v5.9.2
	github.com/riverqueue/river v0.39.0
	github.com/riverqueue/river/riverdriver v0.39.0
	github.com/riverqueue/river/riverdriver/riverpgxv5 v0.39.0
	github.com/riverqueue/river/rivertype v0.39.0
	github.com/stretchr/testify v1.11.1
	github.com/tidwall/gjson v1.19.0
	go.uber.org/goleak v1.3.0
	golang.org/x/mod v0.36.0
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/puddle/v2 v2.2.2 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/tidwall/match v1.2.0 // indirect
	github.com/tidwall/pretty v1.2.1 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/text v0.37.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
