package notifier

import (
	"cmp"
	"context"
	"errors"
	"fmt"
	"strconv"
	"sync"
	"testing"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/stretchr/testify/require"

	"github.com/riverqueue/river/riverdbtest"
	"github.com/riverqueue/river/riverdriver"
	"github.com/riverqueue/river/riverdriver/riverpgxv5"
	"github.com/riverqueue/river/rivershared/riversharedtest"
	"github.com/riverqueue/river/rivershared/startstoptest"
	"github.com/riverqueue/river/rivershared/util/maputil"
	"github.com/riverqueue/river/rivershared/util/randutil"
	"github.com/riverqueue/river/rivershared/util/serviceutil"
)

func TestNotificationTopicLongest(t *testing.T) {
	t.Parallel()

	require.Equal(t, NotificationTopicLeadership, NotificationTopicLongest)
}

func TestNotifier(t *testing.T) {
	t.Parallel()

	const (
		testTopic1 = "test_topic1"
		testTopic2 = "test_topic2"
	)

	ctx := context.Background()

	type testBundle struct {
		dbPool *pgxpool.Pool
		exec   riverdriver.Executor
		schema string
	}

	type testOpts struct {
		dbPool *pgxpool.Pool // may be left nil for riversharedtest.DBPool
	}

	setup := func(t *testing.T, opts *testOpts) (*Notifier, *testBundle) {
		t.Helper()

		if opts == nil {
			opts = &testOpts{}
		}

		var (
			dbPool   = cmp.Or(opts.dbPool, riversharedtest.DBPool(ctx, t))
			driver   = riverpgxv5.New(dbPool)
			schema   = riverdbtest.TestSchema(ctx, t, driver, nil)
			listener = driver.GetListener(&riverdriver.GetListenenerParams{Schema: schema})
		)

		notifier := New(riversharedtest.BaseServiceArchetype(t), listener)
		notifier.testSignals.Init(t)

		return notifier, &testBundle{
			dbPool: dbPool,
			exec:   driver.GetExecutor(),
			schema: schema,
		}
	}

	start := func(t *testing.T, notifier *Notifier) {
		t.Helper()

		require.NoError(t, notifier.Start(ctx))
		t.Cleanup(notifier.Stop)
	}

	t.Run("StartsAndStops", func(t *testing.T) {
		t.Parallel()

		notifier, _ := setup(t, nil)
		start(t, notifier)

		notifier.testSignals.ListeningBegin.WaitOrTimeout()

		notifier.Stop()

		notifier.testSignals.ListeningEnd.WaitOrTimeout()
	})

	t.Run("StartStopStress", func(t *testing.T) {
		t.Parallel()

		notifier, _ := setup(t, &testOpts{dbPool: riversharedtest.DBPoolClone(ctx, t)})
		notifier.Logger = riversharedtest.LoggerWarn(t) // loop started/stop log is very noisy; suppress
		notifier.testSignals = notifierTestSignals{}    // deinit so channels don't fill

		startstoptest.Stress(ctx, t, notifier)
	})

	t.Run("StartErrorsOnImmediateProblem", func(t *testing.T) {
		t.Parallel()

		notifier, bundle := setup(t, &testOpts{dbPool: riversharedtest.DBPoolClone(ctx, t)})

		t.Log("Closing database pool")
		bundle.dbPool.Close()

		require.EqualError(t, notifier.Start(ctx), "closed pool")
	})

	t.Run("ListenErrorsOnImmediateProblem", func(t *testing.T) {
		t.Parallel()

		notifier, _ := setup(t, nil)

		// Use a mock to simulate an error for this one because it's really hard
		// to get the timing right otherwise, and hard to avoid races.
		listenerMock := NewListenerMock(notifier.listener)
		listenerMock.listenFunc = func(ctx context.Context, topic string) error {
			return errors.New("error from listener")
		}
		notifier.listener = listenerMock

		start(t, notifier)

		notifier.testSignals.ListeningBegin.WaitOrTimeout()

		_, err := notifier.Listen(ctx, testTopic1, nil)
		require.EqualError(t, err, fmt.Sprintf("error listening on topic %q: error from listener", testTopic1))

		require.Empty(t, notifier.subscriptions)
	})

	// A reasonable amount of time to wait for a notification that we don't
	// expect to come through before timing out and assuming that it won't.
	const notificationWaitLeeway = 50 * time.Millisecond

	requireNoNotification := func(t *testing.T, notifyChan chan TopicAndPayload) {
		t.Helper()

		if len(notifyChan) > 0 {
			notification := <-notifyChan
			require.FailNow(t, "Expected no more notifications", "Expected no more notifications, but got: %+v", notification)
		}
	}

	t.Run("ListensAndUnlistens", func(t *testing.T) {
		t.Parallel()

		notifier, bundle := setup(t, nil)
		start(t, notifier)

		notifyChan := make(chan TopicAndPayload, 10)

		sub, err := notifier.Listen(ctx, testTopic1, topicAndPayloadNotifyFunc(notifyChan))
		require.NoError(t, err)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg1")

		require.Equal(t, TopicAndPayload{testTopic1, "msg1"}, riversharedtest.WaitOrTimeout(t, notifyChan))

		sub.Unlisten(ctx)

		require.Empty(t, notifier.subscriptions)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg2")

		time.Sleep(notificationWaitLeeway)

		requireNoNotification(t, notifyChan)
	})

	t.Run("ListenWithoutStart", func(t *testing.T) {
		t.Parallel()

		notifier, bundle := setup(t, nil)

		notifyChan := make(chan TopicAndPayload, 10)

		sub, err := notifier.Listen(ctx, testTopic1, topicAndPayloadNotifyFunc(notifyChan))
		require.NoError(t, err)
		t.Cleanup(func() { sub.Unlisten(ctx) })

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg1")

		time.Sleep(notificationWaitLeeway)

		// Not received because the notifier was never started and therefore
		// never started processing messages.
		requireNoNotification(t, notifyChan)
	})

	// This next set of tests are largely here to make sure in case of listen
	// problems, the internal subscriptions map is correctly reset back to its
	// expected state by removing the problematic subscription.

	t.Run("ListenWithoutStartConnectError", func(t *testing.T) {
		t.Parallel()

		notifier, _ := setup(t, nil)

		listenerMock := NewListenerMock(notifier.listener)
		listenerMock.connectFunc = func(ctx context.Context) error {
			return errors.New("error on connect")
		}
		notifier.listener = listenerMock

		_, err := notifier.Listen(ctx, testTopic1, nil)
		require.EqualError(t, err, "error on connect")

		require.Empty(t, notifier.subscriptions)
	})

	t.Run("ListenWithoutStartListenError", func(t *testing.T) {
		t.Parallel()

		notifier, _ := setup(t, nil)

		listenerMock := NewListenerMock(notifier.listener)
		listenerMock.listenFunc = func(ctx context.Context, topic string) error {
			return errors.New("error on listen")
		}
		notifier.listener = listenerMock

		_, err := notifier.Listen(ctx, testTopic1, nil)
		require.EqualError(t, err, fmt.Sprintf("error listening on topic %q: error on listen", testTopic1))

		require.Empty(t, notifier.subscriptions)
	})

	t.Run("ListenWithoutStartMultipleSubscriptionsError", func(t *testing.T) {
		t.Parallel()

		notifier, _ := setup(t, nil)

		listenerMock := NewListenerMock(notifier.listener)
		listenerMock.listenFunc = func(ctx context.Context, topic string) error {
			// First is allowed to succeed. Others fail.
			switch topic {
			case testTopic2:
				return errors.New("error on listen")
			default:
				return listenerMock.Listener.Listen(ctx, topic)
			}
		}
		notifier.listener = listenerMock

		sub, err := notifier.Listen(ctx, testTopic1, nil)
		require.NoError(t, err)
		t.Cleanup(func() { sub.Unlisten(ctx) })

		_, err = notifier.Listen(ctx, testTopic2, nil)
		require.EqualError(t, err, fmt.Sprintf("error listening on topic %q: error on listen", testTopic2))

		// Only the successful subscription is left.
		require.Equal(t, []NotificationTopic{testTopic1}, maputil.Keys(notifier.subscriptions))
	})

	t.Run("ListenBeforeStart", func(t *testing.T) {
		t.Parallel()

		notifier, bundle := setup(t, nil)

		notifyChan := make(chan TopicAndPayload, 10)

		sub, err := notifier.Listen(ctx, testTopic1, topicAndPayloadNotifyFunc(notifyChan))
		require.NoError(t, err)
		t.Cleanup(func() { sub.Unlisten(ctx) })

		start(t, notifier)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg1")

		require.Equal(t, TopicAndPayload{testTopic1, "msg1"}, riversharedtest.WaitOrTimeout(t, notifyChan))
	})

	t.Run("SingleTopicMultipleSubscribers", func(t *testing.T) {
		t.Parallel()

		notifier, bundle := setup(t, nil)
		start(t, notifier)

		notifyChan1 := make(chan TopicAndPayload, 10)
		notifyChan2 := make(chan TopicAndPayload, 10)

		sub1, err := notifier.Listen(ctx, testTopic1, topicAndPayloadNotifyFunc(notifyChan1))
		require.NoError(t, err)
		sub2, err := notifier.Listen(ctx, testTopic1, topicAndPayloadNotifyFunc(notifyChan2))
		require.NoError(t, err)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg1")

		require.Equal(t, TopicAndPayload{testTopic1, "msg1"}, riversharedtest.WaitOrTimeout(t, notifyChan1))
		require.Equal(t, TopicAndPayload{testTopic1, "msg1"}, riversharedtest.WaitOrTimeout(t, notifyChan2))

		sub1.Unlisten(ctx)
		sub2.Unlisten(ctx)

		require.Empty(t, notifier.subscriptions)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg2")

		time.Sleep(notificationWaitLeeway)

		requireNoNotification(t, notifyChan1)
		requireNoNotification(t, notifyChan2)
	})

	t.Run("MultipleTopicsLockStep", func(t *testing.T) {
		t.Parallel()

		notifier, bundle := setup(t, nil)
		start(t, notifier)

		notifyChan1 := make(chan TopicAndPayload, 10)
		notifyChan2 := make(chan TopicAndPayload, 10)

		sub1, err := notifier.Listen(ctx, testTopic1, topicAndPayloadNotifyFunc(notifyChan1))
		require.NoError(t, err)
		sub2, err := notifier.Listen(ctx, testTopic2, topicAndPayloadNotifyFunc(notifyChan2))
		require.NoError(t, err)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg1_1")
		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic2, "msg1_2")

		require.Equal(t, TopicAndPayload{testTopic1, "msg1_1"}, riversharedtest.WaitOrTimeout(t, notifyChan1))
		require.Equal(t, TopicAndPayload{testTopic2, "msg1_2"}, riversharedtest.WaitOrTimeout(t, notifyChan2))

		sub1.Unlisten(ctx)
		sub2.Unlisten(ctx)

		require.Empty(t, notifier.subscriptions)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg2_1")
		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic2, "msg2_2")

		time.Sleep(notificationWaitLeeway)

		requireNoNotification(t, notifyChan1)
		requireNoNotification(t, notifyChan2)
	})

	t.Run("MultipleTopicsStaggered", func(t *testing.T) {
		t.Parallel()

		notifier, bundle := setup(t, nil)
		start(t, notifier)

		notifyChan1 := make(chan TopicAndPayload, 10)
		notifyChan2 := make(chan TopicAndPayload, 10)

		sub1, err := notifier.Listen(ctx, testTopic1, topicAndPayloadNotifyFunc(notifyChan1))
		require.NoError(t, err)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg1_1")
		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic2, "msg1_2")

		time.Sleep(notificationWaitLeeway)

		// Only the first channel is subscribed.
		require.Equal(t, TopicAndPayload{testTopic1, "msg1_1"}, riversharedtest.WaitOrTimeout(t, notifyChan1))
		requireNoNotification(t, notifyChan2)

		sub2, err := notifier.Listen(ctx, testTopic2, topicAndPayloadNotifyFunc(notifyChan2))
		require.NoError(t, err)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg2_1")
		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic2, "msg2_2")

		// Now both subscriptions are active.
		require.Equal(t, TopicAndPayload{testTopic1, "msg2_1"}, riversharedtest.WaitOrTimeout(t, notifyChan1))
		require.Equal(t, TopicAndPayload{testTopic2, "msg2_2"}, riversharedtest.WaitOrTimeout(t, notifyChan2))

		sub1.Unlisten(ctx)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg3_1")
		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic2, "msg3_2")

		time.Sleep(notificationWaitLeeway)

		// First channel unsubscribed, but the second remains.
		requireNoNotification(t, notifyChan1)
		require.Equal(t, TopicAndPayload{testTopic2, "msg3_2"}, riversharedtest.WaitOrTimeout(t, notifyChan2))

		sub2.Unlisten(ctx)

		require.Empty(t, notifier.subscriptions)

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg4_1")
		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic2, "msg4_2")

		time.Sleep(notificationWaitLeeway)

		requireNoNotification(t, notifyChan1)
		requireNoNotification(t, notifyChan2)
	})

	// Stress test meant to suss out any races that there might be in the
	// subscribe or interrupt loop code.
	t.Run("MultipleSubscribersStress", func(t *testing.T) {
		t.Parallel()

		notifier, bundle := setup(t, &testOpts{dbPool: riversharedtest.DBPoolClone(ctx, t)})
		start(t, notifier)

		const (
			numSubscribers         = 10
			numSubscribeIterations = 5
		)

		notifyChans := make([]chan TopicAndPayload, numSubscribers)
		for i := range notifyChans {
			notifyChans[i] = make(chan TopicAndPayload, 1000)
		}

		// Start a goroutine to send messages constantly.
		var (
			sendNotificationsDone     = make(chan struct{})
			sendNotificationsShutdown = make(chan struct{})
		)
		go func() {
			defer close(sendNotificationsDone)

			ticker := time.NewTicker(10 * time.Millisecond)
			defer ticker.Stop()

			for messageNum := 0; ; messageNum++ {
				sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg"+strconv.Itoa(messageNum))

				select {
				case <-ctx.Done():
					return
				case <-sendNotificationsShutdown:
					return
				case <-ticker.C:
					// loop again
				}
			}
		}()

		var wg sync.WaitGroup
		wg.Add(len(notifyChans))
		for i := range notifyChans {
			notifyChan := notifyChans[i]

			go func() {
				defer wg.Done()

				for range numSubscribeIterations {
					sub, err := notifier.Listen(ctx, testTopic1, topicAndPayloadNotifyFunc(notifyChan))
					require.NoError(t, err)

					// Pause a random brief amount of time.
					serviceutil.CancellableSleep(ctx, randutil.DurationBetween(15*time.Millisecond, 50*time.Millisecond))

					// Wait for at least one message to come through. This
					// generally isn't necessary, but we can run into strange
					// problems in slow environments like GitHub Actions where
					// the send goroutine can apparently be paused entirely
					// around the sleep above between listen and unlisten.
					riversharedtest.WaitOrTimeout(t, notifyChan)

					sub.Unlisten(ctx)
				}
			}()
		}

		wg.Wait()                        // wait for subscribe loops to finish all their work
		close(sendNotificationsShutdown) // stop sending notifications
		<-sendNotificationsDone          // wait for notifications goroutine to finish

		for i := range notifyChans {
			// Don't require a specific number of messages to have been received
			// since it's non-deterministic, but every channel should've gotten
			// at least one message (as measured by the WaitOrTimeout above).
			// In my test runs, they receive ~15 each. The WaitOrTimeout
			// consumes one message, so we add +1 when measuring each channel.
			t.Logf("Channel %2d contains %3d message(s)", i, len(notifyChans[i])+1)
		}
	})

	t.Run("WaitErrorAndBackoff", func(t *testing.T) {
		t.Parallel()

		notifier, _ := setup(t, nil)

		notifier.testDisableSleep = true

		var errorNum int

		// Use a mock to simulate an error for this one because it's really hard
		// to get the timing right otherwise, and hard to avoid races.
		listenerMock := NewListenerMock(notifier.listener)
		listenerMock.waitForNotificationFunc = func(ctx context.Context) (*riverdriver.Notification, error) {
			errorNum++
			return nil, fmt.Errorf("error during wait %d", errorNum)
		}
		notifier.listener = listenerMock

		start(t, notifier)

		// The service normally sleeps with an exponential backoff after an
		// error, but we've disabled sleep above, so we can pull errors out of
		// the test signal as quickly as we want.
		require.EqualError(t, notifier.testSignals.BackoffError.WaitOrTimeout(), "error during wait 1")
		require.EqualError(t, notifier.testSignals.BackoffError.WaitOrTimeout(), "error during wait 2")
		require.EqualError(t, notifier.testSignals.BackoffError.WaitOrTimeout(), "error during wait 3")
	})

	t.Run("BackoffSleepCancelledOnStop", func(t *testing.T) {
		t.Parallel()

		notifier, _ := setup(t, nil)

		listenerMock := NewListenerMock(notifier.listener)
		listenerMock.waitForNotificationFunc = func(ctx context.Context) (*riverdriver.Notification, error) {
			return nil, errors.New("error during wait")
		}
		notifier.listener = listenerMock

		start(t, notifier)

		// The loop goes to sleep as soon as it fires this test signal, but it's
		// cancelled immediately as the test cleanup look issues a Stop.
		require.EqualError(t, notifier.testSignals.BackoffError.WaitOrTimeout(), "error during wait")
	})

	t.Run("PingUsesNonCancelledContext", func(t *testing.T) {
		t.Parallel()

		notifier, _ := setup(t, nil)

		// Use a very short ping interval so the test doesn't take 5 seconds.
		notifier.testPingInterval = 50 * time.Millisecond

		var (
			pingCtxCancelled bool
			pingCalled       = make(chan struct{})
			pingOnce         sync.Once
		)

		listenerMock := NewListenerMock(notifier.listener)
		listenerMock.waitForNotificationFunc = func(ctx context.Context) (*riverdriver.Notification, error) {
			// Block until the context is cancelled (which happens when
			// drainErrChan runs after the ping interval elapses).
			<-ctx.Done()
			return nil, ctx.Err()
		}
		listenerMock.pingFunc = func(ctx context.Context) error {
			pingOnce.Do(func() {
				pingCtxCancelled = ctx.Err() != nil
				close(pingCalled)
			})
			return nil
		}
		notifier.listener = listenerMock

		start(t, notifier)

		notifier.testSignals.ListeningBegin.WaitOrTimeout()

		select {
		case <-pingCalled:
		case <-time.After(5 * time.Second):
			require.FailNow(t, "Timed out waiting for Ping to be called")
		}

		require.False(t, pingCtxCancelled,
			"Ping should receive a non-cancelled context; the inner context is "+
				"cancelled to interrupt WaitForNotification, but Ping needs a live context")
	})

	t.Run("StillFunctionalAfterMainLoopFailure", func(t *testing.T) {
		t.Parallel()

		notifier, bundle := setup(t, nil)

		// Disable the backoff sleep that would occur after the first retry.
		notifier.testDisableSleep = true

		var errorNum int

		listenerMock := NewListenerMock(notifier.listener)
		listenerMock.waitForNotificationFunc = func(ctx context.Context) (*riverdriver.Notification, error) {
			// Returns an error the first time, but then works after.
			errorNum++
			switch errorNum {
			case 1:
				return nil, errors.New("error during wait")
			default:
				return listenerMock.Listener.WaitForNotification(ctx)
			}
		}
		notifier.listener = listenerMock

		notifyChan := make(chan TopicAndPayload, 10)

		start(t, notifier)

		notifier.testSignals.ListeningBegin.WaitOrTimeout()

		sub, err := notifier.Listen(ctx, testTopic1, topicAndPayloadNotifyFunc(notifyChan))
		require.NoError(t, err)
		t.Cleanup(func() { sub.Unlisten(ctx) })

		// First failure, after which the loop will reenter and start producing again.
		require.EqualError(t, notifier.testSignals.BackoffError.WaitOrTimeout(), "error during wait")

		// It is possible for notifications to be missed while the loop is
		// restarting, so make sure we're back in the listening loop before
		// sending the notification below.
		notifier.testSignals.ListeningBegin.WaitOrTimeout()

		sendNotification(ctx, t, bundle.exec, bundle.schema, testTopic1, "msg1")

		// Subscription should still work.
		require.Equal(t, TopicAndPayload{testTopic1, "msg1"}, riversharedtest.WaitOrTimeout(t, notifyChan))
	})
}

type ListenerMock struct {
	riverdriver.Listener

	connectFunc             func(ctx context.Context) error
	listenFunc              func(ctx context.Context, topic string) error
	pingFunc                func(ctx context.Context) error
	waitForNotificationFunc func(ctx context.Context) (*riverdriver.Notification, error)
}

func NewListenerMock(listener riverdriver.Listener) *ListenerMock {
	return &ListenerMock{
		Listener: listener,

		connectFunc:             listener.Connect,
		listenFunc:              listener.Listen,
		pingFunc:                listener.Ping,
		waitForNotificationFunc: listener.WaitForNotification,
	}
}

func (l *ListenerMock) Connect(ctx context.Context) error {
	return l.connectFunc(ctx)
}

func (l *ListenerMock) Listen(ctx context.Context, topic string) error {
	return l.listenFunc(ctx, topic)
}

func (l *ListenerMock) Ping(ctx context.Context) error {
	return l.pingFunc(ctx)
}

func (l *ListenerMock) WaitForNotification(ctx context.Context) (*riverdriver.Notification, error) {
	return l.waitForNotificationFunc(ctx)
}

type TopicAndPayload struct {
	topic   NotificationTopic
	payload string
}

func topicAndPayloadNotifyFunc(notifyChan chan TopicAndPayload) NotifyFunc {
	return func(topic NotificationTopic, payload string) {
		notifyChan <- TopicAndPayload{topic, payload}
	}
}

func TestShouldIgnoreListenerError(t *testing.T) {
	t.Parallel()

	t.Run("ContextCanceled", func(t *testing.T) {
		t.Parallel()

		require.True(t, shouldIgnoreListenerError(context.Canceled))
	})

	t.Run("WrappedContextCanceled", func(t *testing.T) {
		t.Parallel()

		require.True(t, shouldIgnoreListenerError(fmt.Errorf("wrapped: %w", context.Canceled)))
	})

	t.Run("TLSCloseNotifyAlert", func(t *testing.T) {
		t.Parallel()

		require.True(t, shouldIgnoreListenerError(errors.New("tls: failed to send closeNotify alert (but connection was closed anyway): write tcp 10.0.5.131:40192->10.0.7.96:5432: i/o timeout")))
	})

	t.Run("ArbitraryError", func(t *testing.T) {
		t.Parallel()

		require.False(t, shouldIgnoreListenerError(errors.New("some other error")))
	})
}

func sendNotification(ctx context.Context, t *testing.T, exec riverdriver.Executor, schema, topic string, payload string) {
	t.Helper()

	t.Logf("Sending notification on %q: %s", topic, payload)
	require.NoError(t, exec.NotifyMany(ctx, &riverdriver.NotifyManyParams{
		Payload: []string{payload},
		Schema:  schema,
		Topic:   topic,
	}))
}
