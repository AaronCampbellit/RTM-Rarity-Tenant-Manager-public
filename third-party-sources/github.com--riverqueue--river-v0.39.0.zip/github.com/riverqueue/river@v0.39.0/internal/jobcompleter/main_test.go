package jobcompleter

import (
	"testing"

	"github.com/riverqueue/river/internal/riverinternaltest"
)

func TestMain(m *testing.M) {
	riverinternaltest.WrapTestMain(m)
}
